/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ildar4ik
 */
class galToLit {
// 1 ���= 12 ������ 1 ����= 39,27 ������ 1 metr= 3.28 fut
    public static void main(String args[]) {
   boolean b;
   
   b = false;
    System.out.println("the symbol 1 " + b);
   b = true; 
    System.out.println("the symbol 2 " + b);
    if (b) System.out.println("it works");
    b=false;
    if (b) System.out.println("it doesnt work");
     System.out.println("10>9" + (10>11));
   
    }}

