

public class scope {
 public static void main(String args[]) {
     double x=10, y=3, z, osstt;
    z=x/y;
    osstt=x%y;
          System.out.println(z+x);
 }  
}
